#Geoestatística no R - Huriel Ruan Reichel

# Average Nearest Neighbour - dados de temperatura
if (!require(rgdal)) {
  install.packages("rgdal", repos = "http://cran.us.r-project.org")
  require(rgdal) # No linux, instalar via sudo apt tende a ser menos problematico
}
temp <- rgdal::readOGR("Temperature/Temperature.shp") 
install.packages("githubinstall")
library(githubinstall)
githubinstall("spatialEco")
library(spatialEco)
spatialEco::nni(temp)
