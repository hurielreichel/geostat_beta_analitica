# Esse script é parte do curso de Introdução à Geoestatística no R da Beta Analítica.
# Autor : Huriel R. Reichel

# Chernobyl
# Importando os dados
chernobyl <- read.csv("1_Spatial_dataset.csv")
names(chernobyl)

# Transformando em geodata
require(geoR)
cs137 <- as.geodata(chernobyl, coords.col = 4:3, data.col = 16)

# Primeira observação
plot(cs137)

# Transformando para escala logaritmica
cs137$data <- log(cs137$data)
plot(cs137)

# variograma
v <- variog(cs137)
plot(v)

# eye-fitting
ef <- eyefit(v)
ef

# ols
ols <- variofit(v, ini = c(4,1.89))
ols
points(cs137)

# grid de prediçao
pred.grid <- expand.grid(seq(26,31, l = 180), seq(49, 52, l = 108))

# Prediçao
kc.ols <- krige.conv(cs137, loc = pred.grid, krige = krige.control(obj.model = ols))

# visualizando
require(RColorBrewer)
pal <- brewer.pal(5, "Reds")
image(kc.ols, col=pal, x.leg = c(51,51.6), y.leg = c(29.6,29.7))

# Exportando para raster
kc.DF <- data.frame(cbind(kc.ols$predict, pred.grid))
colnames(kc.DF)=c("cs", "x", "y")
sp::coordinates(kc.DF)= ~ x + y
require(raster)
kc.DF=rasterFromXYZ(kc.DF)
crs(kc.DF)= crs("+init=epsg:4326")# Atenção
writeRaster(kc.DF, "cs137.tif", format="GTiff", overwrite=TRUE)
rs <- raster("cs137.tif")
plot(rs)

# Epidemia - loa loa
# Importando os dados e criando um índice
loa <- read.table("loaloa.txt")
loa$index <- loa$V4/loa$V3
loa <- as.geodata(loa, coords.col = 1:2, data.col = 8)

# Primeira visualizacao
plot(loa)
points(loa)
bin1 <- variog(loa)
plot(bin1)

# eye-fitting
ef <- eyefit(bin1)
ef

# máxima verossimilhança
ml <- likfit(loa, ini = c(0.08, 4.44), nugget = 0.01, kappa = 2.16, cov.model = 'matern')
summary(ml)
plot(loa)

# Predicao
pred.grid2 <- expand.grid(seq(8,15, l = 112), seq(3, 7, l = 64))
kc.ml <- krige.conv(loa, loc = pred.grid2, krige = krige.control(obj.model = ml2))

pal <- brewer.pal(5, "Greys")
image(kc.ml, x.leg=c(9,14), y.leg=c(2,2.5), col=pal)
summary(kc.ml$predict)

# Simulações condicionais
prob.grid3 <- expand.grid(seq(8,15, l = 56), seq(3, 7, l = 32))
kc.prob3 <- krige.conv(loa, loc = prob.grid3, krige = krige.control(obj.model = ml2),
                       output = output.control(simulations = TRUE, n.pred=1000,
                                               quantile=c(0.10, 0.25, 0.5, 0.75, 0.90),
                                               threshold = 0.3))#atenção ao threshold
# suponha agora que definimos como regiao de alto risco as que possuem prob > 0.6 de estar acima de 0.3
p03 <- apply(kc.prob3$simulations, 1, function(x) mean(x>0.3))
p03.alto <- ifelse(p03 > 0.6, 0, 1)
image(kc.prob3, val=p03.alto, col=c(1,0))

# agora definindo 5 niveis de risco em função da probabilidade
par(mfrow=c(1,1))
image(kc.prob3, val=p03, breaks=seq(0, 1, by=0.2),
      col=pal, x.leg = c(9,14), y.leg = c(2, 2.5), main = 'Prob. of disease index being higher than 0.3')
